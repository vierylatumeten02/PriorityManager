package com.twofaces.androidarchcomponents_mvvm.utilities


const val EXTRA_ID = "com.twofaces.androidarchcomponents_mvvm.EXTRA_ID"
const val EXTRA_TITLE = "com.twofaces.androidarchcomponents_mvvm.EXTRA_TITLE"
const val EXTRA_DESC = "com.twofaces.androidarchcomponents_mvvm.EXTRA_DESC"
const val EXTRA_PRIORITY = "com.twofaces.androidarchcomponents_mvvm.EXTRA_PRIORITY"
const val ADD_NOTE_REQUEST = 1
const val EDIT_NOTE_REQUEST = 2









